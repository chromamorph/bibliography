% Copyright Tom Collins 5/4/2013

% Load Chopin's Nocturne in E major op.62 no.2, run a pattern discovery
% algorithm on it, categorise the output patterns and investigate the
% retrieval of inexact matches to one of the discovered patterns.

% Warning: this collection contains a Matlab version of the fingerprinter
% of Arzt, Böck, and Widmer (2012). It is less stable and slower than their
% implementation. Any discrepancies between results of the two
% implementations are likely errors on my part.

% Define paths.
coreRoot = fullfile('~', 'repos', 'collCodeInit', 'private', 'core',...
  'matlab', 'pattDisc');
projRoot = fullfile('~', 'ConferencesPresentations', 'ISMIR', '2013',...
  'thirdWeekJulyAttempt');
resultPath = fullfile(projRoot, 'chopinOp62No2Results');

% Include necessary code.
addpath(fullfile(coreRoot, 'analysis'),...
  fullfile(coreRoot, 'filter'),...
  fullfile(coreRoot, 'formatUtils'),...
  fullfile(coreRoot, 'patternDiscovery'),...
  fullfile(coreRoot, 'patternMatching'),...
  fullfile(coreRoot, 'rating'),...
  fullfile(coreRoot, 'thirdParty', 'matlabCentral', 'count'));

% Load the point set for Chopin's op.62 no.2.
load(fullfile(resultPath, 'chop_op62_No2.mat'))
D = datasetStruct.pointsOnly;
anchors = datasetStruct.anchors;

% Set parameters for SIARCT and run it.
r = 1;
compactThresh = 4/5;
cardinaThresh = 10;
regionType = 'lexicographic';
[SIARCToutput, runtime, FRT] = SIARCT(D, r, compactThresh,...
  cardinaThresh, regionType);
% runtime = 277.4407 seconds.
% FRT = 0.3257;
save(fullfile(resultPath, 'chopinOp62No2_SIARCT.mat'),...
  'SIARCToutput', 'runtime', 'FRT');
% load(fullfile(resultPath, 'chopinOp62No2_SIARCT.mat'),...
%   'SIARCToutput', 'runtime', 'FRT');

% Rate output.
tfPitch = 1;
tic; warning off
A = rateOutput(SIARCToutput, D, tfPitch);
toc; warning on % Elapsed time is 10.795781 seconds.
save(fullfile(resultPath, 'chopinOp62No2_A.mat'), 'A');
% load(fullfile(resultPath, 'chopinOp62No2_A.mat'), 'A');

% Plot the discovered patterns and save as postscript.
save_path = fullfile(resultPath, 'chopinOp62No2Raw.ps');
allOcc = 0;
n = size(A, 2); % = 76. 
for i = 1:n
    m = A(i).occurrences;
    plotPatternOccurrence(A, D, i, 1, allOcc);
    set(gcf, 'PaperPosition', [0.25 2.5 8.5 4.5]);
    print('-dpsc', '-append', save_path)
    close
end

% Calculate some score matrices.
similarity_fn = 'normalised matching score';
s = scoreMatrix(A, [], [], [], similarity_fn);
imagesc(s)
axis square
save(fullfile(resultPath, 'chopinOp62No2_s.mat'), 's');
% load(fullfile(resultPath, 'chopinOp62No2_s.mat'), 's');

similarity_fn = 'cardinality score';
allowTrans = 1;
t = scoreMatrix(A, [], [], [], similarity_fn, allowTrans);
figure
imagesc(t)
axis square
save(fullfile(resultPath, 'chopinOp62No2_t.mat'), 't');
% load(fullfile(resultPath, 'chopinOp62No2_t.mat'), 't');

% Catgeorise the score matrices, in an attempt to reduce output.
similarThresh = .5;
% NB, scoreMatrix.m applies a sqrt to the resulting histogram, so this
% similarity threshold is actually .25.
similarity_fn = 'normalised matching score';
rating_field = 'rating';
[Bs, categories, ~, ~] =...
  categoriseRatedPatternsBySimilarity(A, rating_field, s, similarThresh,...
  similarity_fn);
% Associate the discovered patterns with the anchors, and save to file.
fname = fullfile(resultPath, 'chopOp62No2_SIARCT-C_NSM=0p5.csv');
SIAstyleStruct2AnchorCsv(Bs, D, anchors, fname)

similarity_fn = 'cardinality score';
[Bt, categoriet, ~, ~] =...
  categoriseRatedPatternsBySimilarity(A, rating_field, t, similarThresh,...
  similarity_fn);
% Associate the discovered patterns with the anchors, and save to file.
fname = fullfile(resultPath, 'chopOp62No2_SIARCT-C_card=0p5.csv');
SIAstyleStruct2AnchorCsv(Bt, D, anchors, fname)

%% chopSimMatUncatCat for ISMIR 2013 paper.
% For NSM, save the uncategorised and categorised similarity matrices for
% the paper.
% First get the permutation index.
perm_idx = zeros(n, 1);
jperm = 1; % Increment to populate perm_idx.
ncat = size(Bs, 2); % = 14.
cat_begin = zeros(ncat, 1);
for icat = 1:ncat
  curr_idx = Bs(icat).categoryIndex;
  cat_begin(icat) = jperm;
  curr_members = Bs(icat).categoryMembersIndex;
  cat_size = size(curr_members, 2);
  perm_idx(jperm:jperm + cat_size - 1) = curr_members';
  jperm = jperm + cat_size;
end
cat_begin = cat_begin - .5;

FontName = 'Helvetica';
FontSize = 20;
close all
figure
colormap(flipud(gray))
imagesc(s)
axis square
set(gca, 'XTick', 10:10:70)
set(gca, 'XTickLabel', 10:10:70)
set(gca, 'YTick', 10:10:70)
set(gca, 'YTickLabel', 10:10:70)
xlabel('Discovered Pattern Index', 'FontName', FontName,...
  'FontSize', FontSize)
ylabel('Discovered Pattern Index', 'FontName', FontName,...
  'FontSize', FontSize)
set(gca, 'FontName', FontName);
set(gca, 'FontSize', FontSize);
print('-dpsc', '-append', fullfile(resultPath, 'simMat_s_uncat.ps'))

close all
figure
colormap(flipud(gray))
imagesc(s(perm_idx, perm_idx))
axis square
hold on
for icat = 1:ncat
  line([cat_begin(icat) cat_begin(icat)], [0 n + 1], 'Color', [1 1 1],...
    'LineWidth', 2)
  line([0 n + 1], [cat_begin(icat) cat_begin(icat)], 'Color', [1 1 1],...
    'LineWidth', 2)
end
hold off
set(gca, 'XTick', 10:10:70)
set(gca, 'XTickLabel', 10:10:70)
set(gca, 'YTick', 10:10:70)
set(gca, 'YTickLabel', 10:10:70)
xlabel('Discovered Pattern Permuted Index', 'FontName', FontName,...
  'FontSize', FontSize)
ylabel('Discovered Pattern Permuted Index', 'FontName', FontName,...
  'FontSize', FontSize)
set(gca, 'FontName', FontName);
set(gca, 'FontSize', FontSize);
print('-dpsc', '-append', fullfile(resultPath, 'simMat_s_cat.ps'))

%% Extra info for chopinOp62No2Themes plot for ISMIR 2013 paper.
% Pattern of interest from Bs is:
idx = 4;
P = Bs(idx).pattern;
nocc = size(Bs(idx).translators, 1);
T = Bs(idx).translators - repmat(Bs(idx).translators(1, :), nocc, 1);
%     0     0
%   104    -2
%   228     0
%   236    -1
% So exact occurrences correspond to bars 1, 27, 58, and 60. We are
% interested in the fp histogram values at these ontimes, as well as at
% bars 9, 17, 25.
fphist1 = fpgethistogram(P, P, 'pitchindependent');
lFP = max(fphist1(:, 2));
fphist2 = fpgethistogram(D, P, 'pitchindependent');
simFP = fphist2(:, 2)/lFP;
figure
plot(fphist2(:, 1), simFP);

% ontime, bar, simFP
%   1      1    .889
%  33      9    .653 (Semiquavers, tuplets)
%  65     17    .264 (This is the one that should be low)
%  97     25    .458 (Florid, arpeggio-like)
% 105     27   1.000 (Very similar to first occurrence)
% 229     58    .944 (Recap)
% 237     60    .889 (Incorrect tie)

% mean(simFP) = .264
% std(simFP) = .173
