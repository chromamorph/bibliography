% Copyright Tom Collins 15/5/2013

% P2FPexample for ISMIR 2013 paper.
% Plot P2 and FP histograms for a particularly representative example.

% This script runs SIARCT on a theme from a Theme and Variation movement by
% Mozart (K331 mvt.1). It rates the output patterns and then uses the top-
% rated pattern as a query into the second variation. The script assesses
% the ability of two pattern matching algorithms (Ukkonen et al.'s P2 and
% Arzt et al.'s symbolic fingerprinter) to retrieve the occurrences of the
% theme in the variation.

% Define paths.
coreRoot = fullfile('~', 'repos', 'collCodeInit', 'private', 'core',...
  'matlab', 'pattDisc');
projRoot = fullfile('~', 'ConferencesPresentations', 'ISMIR', '2013',...
  'thirdWeekJulyAttempt');
resultRoot = fullfile(projRoot, 'mozartK331Mvt1Results');
themeStr = fullfile(resultRoot, 'sonata11-1a.csv');
vartnStr = fullfile(resultRoot, 'sonata11-1c.csv');

% Include necessary code.
addpath(fullfile(coreRoot, 'analysis'),...
  fullfile(coreRoot, 'datasetGeneration'),...
  fullfile(coreRoot, 'filter'),...
  fullfile(coreRoot, 'patternDiscovery'),...
  fullfile(coreRoot, 'patternMatching'),...
  fullfile(coreRoot, 'rating'),...
  fullfile(coreRoot, 'thirdParty', 'matlabCentral', 'count'));

coreRoot = fullfile('~', 'Projects', 'patterns', 'patterns2013');
addpath(fullfile(coreRoot, 'rating'));

% Run pattern discovery on theme and save results.
r = 1;
compactThresh = 1;
cardinaThresh = 10;
regionType = 'lexicographic';
tfPitch = 1;
C = csvread(themeStr);
D = unique(C(:, [1 3]), 'rows');
multiplier = 1; % Crotchet = 1.
D(:, 1) = multiplier*D(:, 1);
piecename = 'mozartK331Mvt1';
[~, partname, ~] = fileparts(themeStr);
fname = fullfile(resultRoot, [piecename '_' partname '_A.mat']);
if exist(fname, 'file') == 2
  load(fullfile(resultRoot, [piecename '_' partname '_A.mat']), 'A');
else
  % Run pattern discovery algorithm and save results.
  [S, runtime, FRT] = SIARCT(D, r, compactThresh, cardinaThresh,...
    regionType);
  save(fullfile(resultRoot, [piecename '_' partname ...
    '_SIARCT.mat']), 'S', 'runtime', 'FRT');
  % Rate output, save, and use top-rated pattern to define query.
  tic; warning off
  A = rateOutput(S, D, tfPitch);
  toc; warning on
  save(fullfile(resultRoot, [piecename '_' partname '_A.mat']), 'A');
end
plot(D(:, 1), D(:, 2), '.k');
hold on
plot(A(1).pattern(:, 1), A(1).pattern(:, 2), '.r');
hold off

% Load the top-rated discovered pattern from the Theme, the point set for
% Variation II, and plot P2 and FP output.

% Theme.
P = A(1).pattern;
lP2 = size(P, 1);
% Also define a point set based on the notes that belong to the top staff.
ts_idx = find(~C(:, 5));
D_ts = unique(C(ts_idx, [1 3]), 'rows');
D_ts(:, 1) = multiplier*D_ts(:, 1);
tf = ismember(P, D_ts, 'rows');
P_ts = P(tf, :);
lP_ts = size(P_ts, 1);

% Variation II.
C = csvread(vartnStr);
D = unique(C(:, [1 3]), 'rows');
D(:, 1) = multiplier*D(:, 1);
% Also define a point set based on the notes that belong to the top staff.
ts_idx = find(~C(:, 5));
D_ts = unique(C(ts_idx, [1 3]), 'rows');

  
% Apply P2 by Ukkonen et al. (2003).
[vectors, vecCount] = translatorsOfPartialPatternInDataset(P, D);
% Normalise.
simP2 = vecCount/lP2;
% Define all possible translations in ontime, and use this to put maximum
% match for each ontime into a match-time plot.
% unqon = unique(vectors(:, 1));
unqon = (-1:48)';
nunq = size(unqon, 1);
simP2maxPerOn = zeros(nunq, 1);
for iunq = 1:nunq
  % Find rows of vectors corresponding to this unique ontime.
  rel_idx = find(vectors(:, 1) == unqon(iunq));
  if ~isempty(rel_idx)
    simP2maxPerOn(iunq) = max(simP2(rel_idx));
  end
end
% Now do the same for the top staff.
[vectors, vecCount] = translatorsOfPartialPatternInDataset(P_ts, D_ts);
% Normalise.
simP2 = vecCount/lP_ts;
% Define all possible translations in ontime, and use this to put maximum
% match for each ontime into a match-time plot.
% unqon = unique(vectors(:, 1));
unqon = (-1:48)';
nunq = size(unqon, 1);
simP2maxPerOn_ts = zeros(nunq, 1);
for iunq = 1:nunq
  % Find rows of vectors corresponding to this unique ontime.
  rel_idx = find(vectors(:, 1) == unqon(iunq));
  if ~isempty(rel_idx)
    simP2maxPerOn_ts(iunq) = max(simP2(rel_idx));
  end
end
  
% Apply fingerprinter (Arzt et al, 2012).
fphist1 = fpgethistogram2(P, P, 'pitchindependent');
lFP = max(fphist1(:, 2));
fphist2 = fpgethistogram2(D, P, 'pitchindependent');
simFP = fphist2(:, 2)/lFP;
% Now do the same for the top staff.
fphist3 = fpgethistogram2(P_ts, P_ts, 'pitchindependent');
lFP = max(fphist3(:, 2));
fphist4 = fpgethistogram2(D_ts, P_ts, 'pitchindependent');
simFP_ts = fphist4(:, 2)/lFP;

% Plot the figure.
FontName = 'Helvetica';
FontSize = 16;
P2col = [.4 .4 .4];
FPcol = [0 0 0];
handStyle = '--';
gCol = [.85 .85 .85]; % Grid colour.

close all
figure
% Add some gridlines and similarity threshold line of c = .375.
hold on
% Draw some gridlines.
for xi = 0:6:48 % Vertical.
  h = line([xi xi], [0 1], 'LineWidth', 2, 'Color', gCol,...
    'LineStyle', ':');
  % Prevent from inclusion in legend.
  hAnnotation = get(h, 'Annotation');
  hLegendEntry = get(hAnnotation, 'LegendInformation');
  set(hLegendEntry, 'IconDisplayStyle', 'off');
end
for yi = 0:.1:1 % Horizontal.
  h = line([-2 48], [yi yi], 'LineWidth', 2, 'Color', gCol,...
    'LineStyle', ':');
  hAnnotation = get(h, 'Annotation');
  hLegendEntry = get(hAnnotation, 'LegendInformation');
  set(hLegendEntry, 'IconDisplayStyle', 'off');
end
% Draw the curves.
plot(unqon, simP2maxPerOn, 'Color', P2col, 'LineStyle', '--',...
  'LineWidth', 3)
plot(fphist2(:, 1), simFP, 'Color', FPcol, 'LineStyle', '--',...
  'LineWidth', 3)
plot(unqon, simP2maxPerOn_ts, 'Color', P2col, 'LineStyle', '-',...
  'LineWidth', 3)
plot(fphist4(:, 1), simFP_ts, 'Color', FPcol, 'LineStyle', '-',...
  'LineWidth', 3)
hold off
xlim([-.5 23.5])
ylim([0 .8])
set(gca, 'XTick', 0:3:24);
set(gca, 'XTickLabel', 1:8);
set(gca, 'YTick', 0:.2:.8)
set(gca, 'YTickLabel', 0:.2:.8)
set(gca, 'FontName', FontName);
set(gca, 'FontSize', FontSize);
xlabel('Bar Number')
ylabel('Musical Similarity in [0, 1]')
legend({'P2' 'FP' 'P2 Top Staff' 'FP Top Staff'},...
  'Location', 'NorthEast', FontSize, 14, 'Interpreter', 'latex')

set(gcf, 'PaperPosition', [0.15 0.15 6 3]); % Left, bott width, height.
% set(gcf, 'PaperSize', [5.7 6.3]); % Width, height.
print('-dpsc', '-append', fullfile(resultRoot, 'P2FPexample.ps'))
