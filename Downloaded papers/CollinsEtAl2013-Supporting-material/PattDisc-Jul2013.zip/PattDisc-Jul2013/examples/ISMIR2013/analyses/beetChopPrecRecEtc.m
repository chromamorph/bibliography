% Copyright Tom Collins 5/4/2013

% Load a ground truth consisting of sectional repetitions in Beethoven and
% Chopin, then use these to evaluate SIA, SIAR, and SIARCT.

% Project paths.
projRoot = fullfile('~', 'ConferencesPresentations', 'ISMIR', '2013',...
  'thirdWeekJulyAttempt');
dataRoot = fullfile(projRoot, 'repeatedSectionsGroundTruth');
coreRoot = fullfile('~', 'repos', 'collCodeInit', 'private', 'core',...
  'matlab', 'pattDisc');
resultPath = fullfile(projRoot, 'pattDiscOut');
evalResultsPath = fullfile(projRoot, 'evaluationResults');

% Add pattern discovery functions to the Matlab path.
addpath(fullfile(coreRoot, 'analysis'))
addpath(fullfile(coreRoot, 'filter'))
addpath(fullfile(coreRoot, 'patternDiscovery'))
addpath(fullfile(coreRoot, 'rating'))
addpath(fullfile(coreRoot, 'thirdParty', 'matlabCentral', 'count'))

% Algorithm parameters.
projectionIdx = [1 3];
r = 1;
compactThresh = 1;
cardinaThresh = 50;
regionType = 'lexicographic';

%% 1. Load the ground truth
contents = dir(fullfile(dataRoot, '*.mat'));
npiece = size(contents, 1);

%% 2. Run the pattern discovery algorithms.
% Get contents of the ith datasetStruct.
for ipiece = 1:npiece
  fprintf('\nAnalysing piece %d of %d.\n', ipiece, npiece)
  load(fullfile(dataRoot, contents(ipiece).name), 'datasetStruct');
  D2 = datasetStruct.pointsOnly;
  % 1. Run SIA.
  [S1, runtime1, FRT1] = SIA(D2);
  fStub = [datasetStruct.compID datasetStruct.name];
  save(fullfile(resultPath, [fStub '_SIA.mat']), 'S1', 'runtime1', 'FRT1');
  % 2. Run SIAR.
  [S2, runtime2, FRT2] = SIAR(D2, r);
  save(fullfile(resultPath, [fStub '_SIAR.mat']), 'S2', 'runtime2',...
    'FRT2');
  % 3. Run SIARCT.
  [S3, runtime3, FRT3] = SIARCT(D2, r, compactThresh, cardinaThresh,...
    regionType, S2, runtime2(2), FRT2);
  save(fullfile(resultPath, [fStub '_SIARCT.mat']), 'S3', 'runtime3',...
    'FRT3');
  % Filter SIA and SIAR by cardinaThresh before evaluation.
  t_start = tic;
  S4 = filterByCardinality(S1, cardinaThresh, Inf);
  runtime4 = runtime1 + toc(t_start);
  FRT4 = FRT1 + toc(t_start);
  save(fullfile(resultPath, [fStub '_SIA_50+.mat']), 'S4', 'runtime4', ...
    FRT4);
  t_start = tic;
  S5 = filterByCardinality(S2, cardinaThresh, Inf);
  runtime5 = runtime2 + toc(t_start);
  FRT5 = FRT2 + toc(t_start);
  save(fullfile(resultPath, [fStub '_SIAR_50+.mat']), 'S5', 'runtime5',...
    FRT5);
end

%% 3. Calculate and save evaluation metrics:
% 1. Precision;
% 2. Recall;
% 3. Establishment precision;
% 4. Establishment recall;
% 5. Number of output patterns;
% 6. Runtime;
% 7. Pre-distribution runtime;
% 8. Fifth return time;
% 9. First five target proportion.
metrics = {'Precision' 'Recall' 'Establishment precision'...'
  'Establishment recall' 'Number of output patterns' 'Runtime'...
  'Pre-distribution runtime' 'Fifth return time'...
  'First five target proportion'};
nmet = 9;

% Evaluation parameters.
similarity_fn = 'cardinality score';
algs_to_eval = {'SIA_50+' 'SIAR_50+' 'SIARCT' 'SIA' 'SIAR'};
% This variable matches algorithm label to the numbering used for Sx in
% step 2 above.
S_idx = {'4' '5' '3' '1' '2'};
nalg = size(algs_to_eval, 2);

% Ground truth contents.
resultsMat = nan(nalg, npiece, nmet);
for ipiece = 1:npiece
  fprintf('\nEvaluation for piece %d of %d.\n', ipiece, npiece)
  load(fullfile(dataRoot, contents(ipiece).name), 'datasetStruct');
  fStub = [datasetStruct.compID datasetStruct.name];
  for ialg = 1:nalg
    alg_curr = algs_to_eval{ialg};
    fprintf('Evaluation for %s, algorithm %d of %d.\n', alg_curr,...
      ialg, nalg)
    Sx = ['S' S_idx{ialg}];
    rx = ['runtime' S_idx{ialg}];
    FRTx = ['FRT' S_idx{ialg}];
    load(fullfile(resultPath, [fStub '_' alg_curr '.mat']), Sx,  rx, FRTx);
    algoOutput = evalin('base', Sx);
    runtime = evalin('base', rx);
    FRT = evalin('base', FRTx);
    
    % 5-8. Number of output patterns, runtime, pre-distribution runtime,
    % and fifth return time.
    fprintf('Evaluating number of output patterns and various runtimes.\n')
    resultsMat(ialg, ipiece, 5) = size(algoOutput, 2);
    resultsMat(ialg, ipiece, 6) = runtime(1);
    if strcmp(alg_curr, 'SIAR')
      resultsMat(ialg, ipiece, 7) = runtime(2);
    end
    resultsMat(ialg, ipiece, 8) = FRT;
  
    if ~strcmp(alg_curr, 'SIA') && ~strcmp(alg_curr, 'SIAR')
      % 1, 2, and 9. Precision, recall, and first five target proportion.
      fprintf('Evaluating precision, recall, and FFTP.\n')
      [p r tf] = precisionRecallTrans(algoOutput, datasetStruct);
      resultsMat(ialg, ipiece, 1) = p;
      resultsMat(ialg, ipiece, 2) = r;
      resultsMat(ialg, ipiece, 9) = tf;
      
      % 3 and 4. Establishment precision and recall.
      fprintf('Evaluating establishment precision and recall.\n')
      [p, r, ~] = estPrecRecMat(datasetStruct, algoOutput, similarity_fn);
      resultsMat(ialg, ipiece, 3) = p;
      resultsMat(ialg, ipiece, 4) = r;
    end
  end
end

% Save results to file.
save(fullfile(evalResultsPath, ['results_' datestr(clock, 30) '.mat']),...
  'resultsMat', 'algs_to_eval', 'contents', 'metrics');
