% Copyright Tom Collins 19/7/2013

% This script checks why SIA fails to return some of the ground-truth
% patterns exactly. It is due to isolated membership.

addpath(fullfile('~', 'repos', 'collCodeInit', 'private', 'core',...
  'matlab', 'pattDisc', 'rating'))
projRoot = fullfile('~', 'ConferencesPresentations', 'ISMIR', '2013',...
  'thirdWeekJulyAttempt');
load(fullfile('projRoot', 'pattDiscOut',...
  'beet_op002_no1_mv1_SIA_50+.mat'));
load(fullfile('projRoot', 'repeatedSectionsGroundTruth',...
  'beet_op002_no1_mv1.mat'));

D = datasetStruct.pointsOnly;

% This chunk of code shows that the exposition is not found by SIA, due to
% isolated membership.
P1 = datasetStruct.details(1).pattern;
v1 = datasetStruct.details(1).translators(2, :);
idx1 = checkForVectorInOutput(S4, v1);
Q1 = S4(idx1).pattern;
close all
figure
plot(D(:, 1), D(:, 2), '.b')
hold on
plot(Q1(:, 1), Q1(:, 2), '.r');
plot(P1(:, 1), P1(:, 2), '.g');
legend({'Point in Piece' 'Point in MTP' 'Point in Ground Truth'})
hold off

% This chunk of code shows that the development and recapitulation is also
% not found by SIA, due to isolated membership.
P2 = datasetStruct.details(2).pattern;
v2 = datasetStruct.details(2).translators(2, :);
idx2 = checkForVectorInOutput(S4, v2);
Q2 = S4(idx2).pattern;
close all
figure
plot(D(:, 1), D(:, 2), '.b')
hold on
plot(Q2(:, 1), Q2(:, 2), '.r');
plot(P2(:, 1), P2(:, 2), '.g');
legend({'Point in Piece' 'Point in MTP' 'Point in Ground Truth'})
hold off
