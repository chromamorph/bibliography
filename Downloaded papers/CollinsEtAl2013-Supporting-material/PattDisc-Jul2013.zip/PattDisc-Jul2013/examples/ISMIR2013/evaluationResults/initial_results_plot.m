% Copyright Tom Collins 4/6/2013

% This script produces Figure 4 in the paper

% Some paths, fonts, and colours.
evalRoot = fullfile('~', 'ConferencesPresentations', 'ISMIR', '2013',...
  'thirdWeekJulyAttempt', 'evaluationResults');
FontName = 'Helvetica';
FontSize = 18;
gCol = repmat(0.85, 1, 3); % Shading of the grid lines.
lCol = [.5 .5 .5; .25 .25 .25; 0 0 0; .5 .5 .5; .25 .25 .25]; % Shading.
% lCol = {'b' 'g' 'r'}
lSty = {':' '--' '-' ':' '--'}; % Style of the lines.
mSty = {'x' 'x' 'x' 'o' 'o'}; % Style of the markers.

%% Load some stuff for the plot.
load(fullfile(evalRoot, 'results_20130405T171207.mat'));

% Useful piece labels.
ncont = size(contents, 1);
xlab = cell(1, ncont);
for icont = 1:ncont
  curr_score = regexp(contents(icont).name, '.mat', 'split');
  xlab{icont} = curr_score{1}(6:end);
end

%% Plot of log number of output patterns.
figure
hold on
% Draw some grid lines.
for i = 1:12 % Vertical lines
  hobj = line([i i], [1 15], 'Color', [.95 .95 .95], 'LineStyle', '--',...
    'LineWidth', 2);
  % Prevent from inclusion in legend.
  hAnnotation = get(hobj,'Annotation');
  hLegendEntry = get(hAnnotation','LegendInformation');
  set(hLegendEntry,'IconDisplayStyle','off')
end
% for i = 1:ncont % Add text of mvt/piece names.
%   hobj = text(i+.5, 9.5, xlab{i}, 'Color', gCol, 'Rotation', 90,...
%     'VerticalAlignment', 'bottom', 'FontName', FontName,...
%     'FontSize', 0.75*FontSize, 'Interpreter', 'none');
%   % Prevent from inclusion in legend.
%   hAnnotation = get(hobj,'Annotation');
%   hLegendEntry = get(hAnnotation','LegendInformation');
%   set(hLegendEntry,'IconDisplayStyle','off')
% end
for i = 0:2.5:15
  hobj = line([0 13], [i i], 'Color', [.95 .95 .95], 'LineStyle', '--',...
    'LineWidth', 2);
  % Prevent from inclusion in legend.
  hAnnotation = get(hobj,'Annotation');
  hLegendEntry = get(hAnnotation','LegendInformation');
  set(hLegendEntry,'IconDisplayStyle','off')
end

% Add on a very small amount from SIA: it is always more than SIAR, but
% cannot be seen in plot otherwise.
addon = [0 0 0 0 0];
plotOrder = [4 1 5 2 3];
for ialg = 1:5
  plot(log(resultsMat(plotOrder(ialg), :, 5)) + addon(plotOrder(ialg)),...
    'Color', lCol(plotOrder(ialg), :),...
    'LineStyle', lSty{plotOrder(ialg)}, 'LineWidth', 3,...
    'Marker', mSty{plotOrder(ialg)}, 'MarkerSize', 9);
end

xlim([0.5 12.5])
set(gca, 'FontName', FontName);
set(gca, 'FontSize', FontSize);
set(gca, 'XTick', []);
xlabel('Movement or Piece', 'FontName', FontName, 'FontSize', FontSize);

ylim([1 15])
% set(gca, 'YTick', 0:.2:1);
% set(gca, 'YTickLabel', 0:2:10);
ylabel('Log Total No. Patterns Returned', 'FontName', FontName,...
  'FontSize', FontSize);

% title('What a lovely plot', 'FontName', FontName, 'FontSize', FontSize)
legend({'SIA' 'SIA (50+)' 'SIAR' 'SIAR (50+)' 'SIARCT'},...
  'Location', [.21 .35 .1 .1], 'FontSize', .65*FontSize)
hold off

set(gcf, 'PaperSize', [6 5]);
set(gcf, 'PaperPosition', [0 0 6 5]); % left, bottom, width, height.
% orient landscape
print('-dpsc', '-append', fullfile(evalRoot, 'log_no_patt.ps'))

%% Plot of establishment precision.
figure
hold on
% Draw some grid lines.
for i = 1:12 % Vertical lines
  hobj = line([i i], [0 1], 'Color', [.95 .95 .95], 'LineStyle', '--',...
    'LineWidth', 2);
  % Prevent from inclusion in legend.
  hAnnotation = get(hobj,'Annotation');
  hLegendEntry = get(hAnnotation','LegendInformation');
  set(hLegendEntry,'IconDisplayStyle','off')
end
% for i = 1:ncont % Add text of mvt/piece names.
%   hobj = text(i+.5, .2, xlab{i}, 'Color', gCol, 'Rotation', 90,...
%     'VerticalAlignment', 'bottom', 'FontName', FontName,...
%     'FontSize', FontSize, 'Interpreter', 'none');
%   % Prevent from inclusion in legend.
%   hAnnotation = get(hobj,'Annotation');
%   hLegendEntry = get(hAnnotation','LegendInformation');
%   set(hLegendEntry,'IconDisplayStyle','off')
% end
for i = 0:.1:1
  hobj = line([0 13], [i i], 'Color', [.95 .95 .95], 'LineStyle', '--',...
    'LineWidth', 2);
  % Prevent from inclusion in legend.
  hAnnotation = get(hobj,'Annotation');
  hLegendEntry = get(hAnnotation','LegendInformation');
  set(hLegendEntry,'IconDisplayStyle','off')
end

% Subtract a very small amount from SIA: it is always less than SIAR, but
% cannot be seen in plot otherwise.
subtr = [0.015 0 0];
for ialg = 1:3
  plot(resultsMat(ialg, :, 3) - subtr(ialg), 'Color', lCol(ialg, :),...
    'LineStyle', lSty{ialg}, 'LineWidth', 3, 'Marker', mSty{ialg},...
    'MarkerSize', 9);
end

xlim([0.5 12.5])
set(gca, 'FontName', FontName);
set(gca, 'FontSize', FontSize);
set(gca, 'XTick', []);
xlabel('Movement or Piece', 'FontName', FontName, 'FontSize', FontSize);

ylim([0 1])
% set(gca, 'YTick', 0:.2:1);
% set(gca, 'YTickLabel', 0:2:10);
ylabel('Establishment Precision', 'FontName', FontName,...
  'FontSize', FontSize);

% title('What a lovely plot', 'FontName', FontName, 'FontSize', FontSize)
legend({'SIA (50+)' 'SIAR (50+)' 'SIARCT'})
hold off

set(gcf, 'PaperSize', [6 5]);
set(gcf, 'PaperPosition', [0 0 6 5]); % left, bottom, width, height.
% orient landscape
print('-dpsc', '-append', fullfile(evalRoot, 'est_prec.ps'))

%% Plot establishment recall.
figure
hold on
% Draw some grid lines.
for i = 1:12 % Vertical lines
  hobj = line([i i], [0 1], 'Color', [.95 .95 .95], 'LineStyle', '--',...
    'LineWidth', 2);
  % Prevent from inclusion in legend.
  hAnnotation = get(hobj,'Annotation');
  hLegendEntry = get(hAnnotation','LegendInformation');
  set(hLegendEntry,'IconDisplayStyle','off')
end
% for i = 1:ncont % Add text of mvt/piece names.
%   hobj = text(i+.5, .4, xlab{i}, 'Color', gCol, 'Rotation', 90,...
%     'VerticalAlignment', 'bottom', 'FontName', FontName,...
%     'FontSize', FontSize, 'Interpreter', 'none');
%   % Prevent from inclusion in legend.
%   hAnnotation = get(hobj,'Annotation');
%   hLegendEntry = get(hAnnotation','LegendInformation');
%   set(hLegendEntry,'IconDisplayStyle','off')
% end
for i = 0:.1:1
  hobj = line([0 13], [i i], 'Color', [.95 .95 .95], 'LineStyle', '--',...
    'LineWidth', 2);
  % Prevent from inclusion in legend.
  hAnnotation = get(hobj,'Annotation');
  hLegendEntry = get(hAnnotation','LegendInformation');
  set(hLegendEntry,'IconDisplayStyle','off')
end

% Subtract a very small amount from SIA: it is always less than SIAR, but
% cannot be seen in plot otherwise.
subtr = [0.015 0 0];
for ialg = 1:3
  plot(resultsMat(ialg, :, 4) - subtr(ialg), 'Color', lCol(ialg, :),...
    'LineStyle', lSty{ialg}, 'LineWidth', 3, 'Marker', mSty{ialg},...
    'MarkerSize', 9);
end

xlim([0.5 12.5])
set(gca, 'FontName', FontName);
set(gca, 'FontSize', FontSize);
set(gca, 'XTick', []);
xlabel('Movement or Piece', 'FontName', FontName, 'FontSize', FontSize);

ylim([0 1])
ylabel('Establishment Recall', 'FontName', FontName,...
  'FontSize', FontSize);

legend({'SIA (50+)' 'SIAR (50+)' 'SIARCT'}, 'Location', 'SouthWest')
hold off

set(gcf, 'PaperSize', [6 5]);
set(gcf, 'PaperPosition', [0 0 6 5]); % left, bottom, width, height.
print('-dpsc', '-append', fullfile(evalRoot, 'est_rec.ps'))

%% Plot precision.
figure
hold on
% Draw some grid lines.
for i = 1:12 % Vertical lines
  hobj = line([i i], [-.1 1], 'Color', [.95 .95 .95], 'LineStyle', '--',...
    'LineWidth', 2);
  % Prevent from inclusion in legend.
  hAnnotation = get(hobj,'Annotation');
  hLegendEntry = get(hAnnotation','LegendInformation');
  set(hLegendEntry,'IconDisplayStyle','off')
end
% for i = 1:ncont % Add text of mvt/piece names.
%   hobj = text(i+.5, .1, xlab{i}, 'Color', gCol, 'Rotation', 90,...
%     'VerticalAlignment', 'bottom', 'FontName', FontName,...
%     'FontSize', FontSize, 'Interpreter', 'none');
%   % Prevent from inclusion in legend.
%   hAnnotation = get(hobj,'Annotation');
%   hLegendEntry = get(hAnnotation','LegendInformation');
%   set(hLegendEntry,'IconDisplayStyle','off')
% end
for i = 0:.05:.3
  hobj = line([0 13], [i i], 'Color', [.95 .95 .95], 'LineStyle', '--',...
    'LineWidth', 2);
  % Prevent from inclusion in legend.
  hAnnotation = get(hobj,'Annotation');
  hLegendEntry = get(hAnnotation','LegendInformation');
  set(hLegendEntry,'IconDisplayStyle','off')
end

% Add a very small amount to SIAR: the two lines cannot be seen in plot
% otherwise.
subtr = [0 -.0025 0];
for ialg = 1:3
  plot(resultsMat(ialg, :, 1) - subtr(ialg), 'Color', lCol(ialg, :),...
    'LineStyle', lSty{ialg}, 'LineWidth', 3, 'Marker', mSty{ialg},...
    'MarkerSize', 9);
end

xlim([0.5 12.5])
set(gca, 'FontName', FontName);
set(gca, 'FontSize', FontSize);
set(gca, 'XTick', []);
xlabel('Movement or Piece', 'FontName', FontName, 'FontSize', FontSize);

ylim([-.01 .31])
ylabel('Precision', 'FontName', FontName,...
  'FontSize', FontSize);

legend({'SIA (50+)' 'SIAR (50+)' 'SIARCT'})
hold off

set(gcf, 'PaperSize', [6 5]);
set(gcf, 'PaperPosition', [0 0 6 5]); % left, bottom, width, height.
print('-dpsc', '-append', fullfile(evalRoot, 'prec.ps'))

%% Plot recall.

figure
hold on
% Draw some grid lines.
for i = 1:12 % Vertical lines
  hobj = line([i i], [-.1 1], 'Color', [.95 .95 .95], 'LineStyle', '--',...
    'LineWidth', 2);
  % Prevent from inclusion in legend.
  hAnnotation = get(hobj,'Annotation');
  hLegendEntry = get(hAnnotation','LegendInformation');
  set(hLegendEntry,'IconDisplayStyle','off')
end
% for i = 1:ncont % Add text of mvt/piece names.
%   hobj = text(i+.5, .1, xlab{i}, 'Color', gCol, 'Rotation', 90,...
%     'VerticalAlignment', 'bottom', 'FontName', FontName,...
%     'FontSize', FontSize, 'Interpreter', 'none');
%   % Prevent from inclusion in legend.
%   hAnnotation = get(hobj,'Annotation');
%   hLegendEntry = get(hAnnotation','LegendInformation');
%   set(hLegendEntry,'IconDisplayStyle','off')
% end
for i = 0:.1:1
  hobj = line([0 13], [i i], 'Color', [.95 .95 .95], 'LineStyle', '--',...
    'LineWidth', 2);
  % Prevent from inclusion in legend.
  hAnnotation = get(hobj,'Annotation');
  hLegendEntry = get(hAnnotation','LegendInformation');
  set(hLegendEntry,'IconDisplayStyle','off')
end

% Add a very small amount to SIAR: the two lines cannot be seen in plot
% otherwise.
subtr = [0 -.005 0];
for ialg = 1:3
  plot(resultsMat(ialg, :, 2) - subtr(ialg), 'Color', lCol(ialg, :),...
    'LineStyle', lSty{ialg}, 'LineWidth', 3, 'Marker', mSty{ialg},...
    'MarkerSize', 9);
end

xlim([0.5 12.5])
set(gca, 'FontName', FontName);
set(gca, 'FontSize', FontSize);
set(gca, 'XTick', []);
xlabel('Movement or Piece', 'FontName', FontName, 'FontSize', FontSize);

ylim([-.01 1])
ylabel('Recall', 'FontName', FontName,...
  'FontSize', FontSize);

% legend({'SIA (50+)' 'SIAR (50+)' 'SIARCT'})
hold off

set(gcf, 'PaperSize', [6 5]);
set(gcf, 'PaperPosition', [0 0 6 5]); % left, bottom, width, height.
print('-dpsc', '-append', fullfile(evalRoot, 'rec.ps'))

%% Some other common commands.
subplot(1, 2, 1)
clims([2 10])
imagesc(D)
axis equal
colormap(flipud(bone))
